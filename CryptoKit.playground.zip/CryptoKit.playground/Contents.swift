import CryptoKit
import Foundation

let data = Data("Hello".utf8)

// MARK: Hashing

// In one call
let hash = SHA256.hash(data: data)
print(hash.description)
// SHA256 digest: 185f8db32271fe25f561a6fc938b2e264306ec304eda518007d1764826381969

// Computing a hash iteratively
var hasher = SHA256()
hasher.update(data: data)
hasher.update(data: data)
let finalDigest = hasher.finalize()
print(finalDigest.description)
// SHA256 digest: 18c84c4e92bc9c408bdc0738577c3ddc2eaa688ee09a7492e99b0b7ffb62888f
assert(finalDigest == SHA256.hash(data: Data("HelloHello".utf8)))



// MARK: Authentication with HMAC

// generating authentication code and authentication code data
let key = SymmetricKey(size: .bits128)
let authenticationCode = HMAC<SHA256>.authenticationCode(for: data, using: key)
print(authenticationCode)
// HMAC with SHA256: 14d88f3751f5adfb4f79fb5b117c5f8462a33ccaa8e6acc7ef5ae8eb23a2423d

// Convert HMAC to data
// We normally send the authentication code as data over network
let authenticationCodeData = Data(authenticationCode)

// the comparison of a MAC with Data does not leak the shared prefix between the computed value and the value to be verified to protect against timing attacks
assert(authenticationCode == authenticationCodeData)

// verify a MAC
let isValidCode = HMAC<SHA256>.isValidAuthenticationCode(authenticationCodeData, authenticating: data, using: key)
print("Authentication Code Valid: \(isValidCode)")


// MARK: Symmetric Encryption with Ciphers
let cryptoKey = SymmetricKey(size: .bits128)

// encryption
let encryptedContent = try? AES.GCM.seal(data, using: cryptoKey).combined
print("Encrypted Content")
print(encryptedContent?.base64EncodedString() ?? "Encryption Failed")

// decryption
let sealedBox = try! AES.GCM.SealedBox(combined: encryptedContent!)
let decryptedContent = try! AES.GCM.open(sealedBox, using: cryptoKey)

assert(decryptedContent == data)


// MARK: Cryptographic Signature (Digital Signature)
// Use a private key to sign data.
// Anyone with the corresponding public key can verify the signature.

// create a private key
let privateKey = Curve25519.Signing.PrivateKey()
let privateKeyData = privateKey.rawRepresentation
print("Private key")
print(privateKeyData.base64EncodedString())

// sign a piece of data with the key
let signature = try? privateKey.signature(for: data)
print("Signature")
print(signature?.base64EncodedString() ?? "Failed to sign the data")

// Get the public key
let publicKey = privateKey.publicKey
// We normally send public key as data over the network
let publicKeyData = publicKey.rawRepresentation
print("Public Key")
print(publicKeyData.base64EncodedString())

// validate signature
let isValidSignature = (try? Curve25519.Signing.PublicKey(rawRepresentation: publicKeyData))?.isValidSignature(signature!, for: data)
print("Signature Valid: \(isValidSignature ?? false)")


// MARK: Key Agreement
// Use key agreement to establish a shared secret between two parties, each with their own private keys.

// if using x963DerivedSymmetricKey to calculate symmetric key, salt is not needed
let protocolSalt = Data("Some Key Agreement Salt".utf8)
let hashFunction = SHA256.self
// The shared information to use for key derivation.
let sharedInfo = Data()
let outputByteCount = 32

let partyOnePrivateKey = Curve25519.KeyAgreement.PrivateKey()
// public key to publish to party Two
let partyOnePublicKey = partyOnePrivateKey.publicKey


let partyTwoPrivateKey = Curve25519.KeyAgreement.PrivateKey()
// public key to publish to party One
let partyTwoPublicKey = partyTwoPrivateKey.publicKey

let partyOneSharedSecret = try partyOnePrivateKey.sharedSecretFromKeyAgreement(with: partyTwoPublicKey)
let partyOneSymmetricKey = partyOneSharedSecret.hkdfDerivedSymmetricKey(using: hashFunction, salt: protocolSalt, sharedInfo: sharedInfo, outputByteCount: outputByteCount)

let partyTwoSharedSecret = try partyTwoPrivateKey.sharedSecretFromKeyAgreement(with: partyOnePublicKey)
let partyTwoSymmetricKey = partyTwoSharedSecret.hkdfDerivedSymmetricKey(using: hashFunction, salt: protocolSalt, sharedInfo: sharedInfo, outputByteCount: outputByteCount)

// same symmetric key to use for authentication or encryption
assert(partyOneSymmetricKey == partyTwoSymmetricKey)



// MARK: Hybrid public key encryption (HPKE)

// cipher suites:
//
// Parameters:
// - kem: The key encapsulation mechanism (KEM) for encapsulating the symmetric key.
// - kdf: The key derivation function (KDF) for deriving the symmetric key
// - aead: The authenticated encryption with additional data (AEAD) algorithm for encrypting and decrypting messages
//
// The suite can also be created directly by providing the parameters above using init(kem: HPKE.KEM, kdf: HPKE.KDF, aead: HPKE.AEAD).
//
// The sender and recipient of encrypted messages need to use the same cipher suite.
let cipherSuite = HPKE.Ciphersuite.P256_SHA256_AES_GCM_256

// This string identifies a particular use, with its own derivation schedule for the symmetric encryption key.
let protocolInfo = Data("Some Protocol Info".utf8)

// The private and public encryption key of the receiver
// Using same key cryptography as above, in this case P256
let recipientPrivateKey = P256.KeyAgreement.PrivateKey()
let recipientPublicKey = recipientPrivateKey.publicKey

// Sending Message
var hpkeSender = try! HPKE.Sender(recipientKey: recipientPublicKey, ciphersuite: cipherSuite, info: protocolInfo)
let message = Data("Hello From Itsuki!".utf8)
// The ciphertext for the recipient to decrypt.
let cipherText = try! hpkeSender.seal(message)
print("Cipher Text")
print(cipherText.base64EncodedString())
// The encapsulated symmetric key that the recipient uses to decrypt messages.
let encapsulatedKey = hpkeSender.encapsulatedKey
print("Encapsulated Key")
print(encapsulatedKey.base64EncodedString())

// Receiving Message
var hpkeRecipient = try HPKE.Recipient(privateKey: recipientPrivateKey, ciphersuite: cipherSuite, info: protocolInfo, encapsulatedKey: encapsulatedKey)
let openedTextData = try hpkeRecipient.open(cipherText)
assert(openedTextData == message)
